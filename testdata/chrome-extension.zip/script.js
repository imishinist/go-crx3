
window.addEventListener('load', (e) => {
  console.log("test extension", e):
});
